/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0xef153c89 */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/XProjects/ISE10.1i/MultiUART/Src/WCX16.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {5U, 0U};
static unsigned int ng3[] = {1U, 0U};
static unsigned int ng4[] = {6U, 0U};
static unsigned int ng5[] = {2U, 0U};
static unsigned int ng6[] = {7U, 0U};
static unsigned int ng7[] = {3U, 0U};
static unsigned int ng8[] = {8U, 0U};
static const char *ng9 = "Src/WC_RAM.mif";
static int ng10[] = {0, 0};
static int ng11[] = {15, 0};
static unsigned int ng12[] = {15U, 0U};
static unsigned int ng13[] = {4U, 0U};
static unsigned int ng14[] = {9U, 0U};
static unsigned int ng15[] = {10U, 0U};
static unsigned int ng16[] = {11U, 0U};
static unsigned int ng17[] = {12U, 0U};
static unsigned int ng18[] = {13U, 0U};
static unsigned int ng19[] = {14U, 0U};



static void A53_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 2064U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(53, ng0);
    t2 = (t0 + 3012);
    *((int *)t2) = 1;
    t3 = (t0 + 2092);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(54, ng0);

LAB5:    xsi_set_current_line(55, ng0);
    t4 = (t0 + 916U);
    t5 = *((char **)t4);

LAB6:    t4 = ((char*)((ng1)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t4, 2);
    if (t6 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng3)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng5)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng7)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB13;

LAB14:
LAB15:    goto LAB2;

LAB7:    xsi_set_current_line(56, ng0);
    t7 = ((char*)((ng2)));
    t8 = (t0 + 1404);
    xsi_vlogvar_generic_wait_assign_value(t8, t7, 2, 0, 0, 4, 0LL);
    goto LAB15;

LAB9:    xsi_set_current_line(57, ng0);
    t3 = ((char*)((ng4)));
    t4 = (t0 + 1404);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB15;

LAB11:    xsi_set_current_line(58, ng0);
    t3 = ((char*)((ng6)));
    t4 = (t0 + 1404);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB15;

LAB13:    xsi_set_current_line(59, ng0);
    t3 = ((char*)((ng8)));
    t4 = (t0 + 1404);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB15;

}

static void C65_1(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    char *t47;

LAB0:    t1 = (t0 + 2192U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 740U);
    t3 = *((char **)t2);
    t2 = (t0 + 828U);
    t4 = *((char **)t2);
    t6 = *((unsigned int *)t3);
    t7 = *((unsigned int *)t4);
    t8 = (t6 | t7);
    *((unsigned int *)t5) = t8;
    t2 = (t3 + 4U);
    t9 = (t4 + 4U);
    t10 = (t5 + 4U);
    t11 = *((unsigned int *)t2);
    t12 = *((unsigned int *)t9);
    t13 = (t11 | t12);
    *((unsigned int *)t10) = t13;
    t14 = *((unsigned int *)t10);
    t15 = (t14 != 0);
    if (t15 == 1)
        goto LAB4;

LAB5:
LAB6:    t32 = (t0 + 3096);
    t33 = (t32 + 32U);
    t34 = *((char **)t33);
    t35 = (t34 + 40U);
    t36 = *((char **)t35);
    t37 = (t36 + 4U);
    t38 = 1U;
    t39 = t38;
    t40 = (t5 + 4U);
    t41 = *((unsigned int *)t5);
    t38 = (t38 & t41);
    t42 = *((unsigned int *)t40);
    t39 = (t39 & t42);
    t43 = *((unsigned int *)t36);
    *((unsigned int *)t36) = (t43 & 4294967294U);
    t44 = *((unsigned int *)t36);
    *((unsigned int *)t36) = (t44 | t38);
    t45 = *((unsigned int *)t37);
    *((unsigned int *)t37) = (t45 & 4294967294U);
    t46 = *((unsigned int *)t37);
    *((unsigned int *)t37) = (t46 | t39);
    xsi_driver_vfirst_trans(t32, 0, 0);
    t47 = (t0 + 3020);
    *((int *)t47) = 1;

LAB1:    return;
LAB4:    t16 = *((unsigned int *)t5);
    t17 = *((unsigned int *)t10);
    *((unsigned int *)t5) = (t16 | t17);
    t18 = (t3 + 4U);
    t19 = (t4 + 4U);
    t20 = *((unsigned int *)t18);
    t21 = (~(t20));
    t22 = *((unsigned int *)t3);
    t23 = (t22 & t21);
    t24 = *((unsigned int *)t19);
    t25 = (~(t24));
    t26 = *((unsigned int *)t4);
    t27 = (t26 & t25);
    t28 = (~(t23));
    t29 = (~(t27));
    t30 = *((unsigned int *)t10);
    *((unsigned int *)t10) = (t30 & t28);
    t31 = *((unsigned int *)t10);
    *((unsigned int *)t10) = (t31 & t29);
    goto LAB6;

}

static void I67_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;

LAB0:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 1588);
    t2 = ((char*)((ng10)));
    t3 = ((char*)((ng11)));
    xsi_vlogfile_readmemb(ng9, 0, t1, 1, *((unsigned int *)t2), 1, *((unsigned int *)t3));

LAB1:    return;
}

static void A69_3(char *t0)
{
    char t11[8];
    char t12[8];
    char t36[8];
    char t37[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;
    char *t26;
    char *t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    unsigned int t46;
    int t47;
    char *t48;
    unsigned int t49;
    int t50;
    int t51;
    unsigned int t52;
    unsigned int t53;
    int t54;
    int t55;

LAB0:    t1 = (t0 + 2448U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(69, ng0);
    t2 = (t0 + 3028);
    *((int *)t2) = 1;
    t3 = (t0 + 2476);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(70, ng0);

LAB5:    xsi_set_current_line(71, ng0);
    t4 = (t0 + 1092U);
    t5 = *((char **)t4);
    t4 = (t5 + 4U);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(72, ng0);
    t13 = (t0 + 740U);
    t14 = *((char **)t13);
    memset(t12, 0, 8);
    t13 = (t12 + 4U);
    t15 = (t14 + 4U);
    t16 = *((unsigned int *)t15);
    t17 = (~(t16));
    t18 = *((unsigned int *)t14);
    t19 = (t18 & t17);
    t20 = (t19 & 1U);
    if (t20 != 0)
        goto LAB9;

LAB10:    if (*((unsigned int *)t15) != 0)
        goto LAB11;

LAB12:    t21 = (t12 + 4U);
    t22 = *((unsigned int *)t12);
    t23 = *((unsigned int *)t21);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB13;

LAB14:    t28 = *((unsigned int *)t12);
    t29 = (~(t28));
    t30 = *((unsigned int *)t21);
    t31 = (t29 || t30);
    if (t31 > 0)
        goto LAB15;

LAB16:    if (*((unsigned int *)t21) > 0)
        goto LAB17;

LAB18:    if (*((unsigned int *)t12) > 0)
        goto LAB19;

LAB20:    memcpy(t11, t34, 8);

LAB21:    t35 = (t0 + 1588);
    t38 = (t0 + 1588);
    t39 = (t38 + 40U);
    t40 = *((char **)t39);
    t41 = (t0 + 1588);
    t42 = (t41 + 36U);
    t43 = *((char **)t42);
    t44 = (t0 + 652U);
    t45 = *((char **)t44);
    xsi_vlog_generic_convert_array_indices(t36, t37, t40, t43, 2, 1, t45, 4, 2);
    t44 = (t36 + 4U);
    t46 = *((unsigned int *)t44);
    t47 = (!(t46));
    t48 = (t37 + 4U);
    t49 = *((unsigned int *)t48);
    t50 = (!(t49));
    t51 = (t47 && t50);
    if (t51 == 1)
        goto LAB22;

LAB23:    goto LAB8;

LAB9:    *((unsigned int *)t12) = 1;
    goto LAB12;

LAB11:    *((unsigned int *)t12) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB12;

LAB13:    t25 = (t0 + 1404);
    t26 = (t25 + 32U);
    t27 = *((char **)t26);
    goto LAB14;

LAB15:    t32 = (t0 + 1496);
    t33 = (t32 + 32U);
    t34 = *((char **)t33);
    goto LAB16;

LAB17:    xsi_vlog_unsigned_bit_combine(t11, 4, t27, 4, t34, 4);
    goto LAB21;

LAB19:    memcpy(t11, t27, 8);
    goto LAB21;

LAB22:    t52 = *((unsigned int *)t36);
    t53 = *((unsigned int *)t37);
    t54 = (t52 - t53);
    t55 = (t54 + 1);
    xsi_vlogvar_generic_wait_assign_value(t35, t11, 2, 0, *((unsigned int *)t37), t55, 1000000LL);
    goto LAB23;

}

static void C75_4(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;

LAB0:    t1 = (t0 + 2576U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 1588);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t6 = (t0 + 1588);
    t7 = (t6 + 40U);
    t8 = *((char **)t7);
    t9 = (t0 + 1588);
    t10 = (t9 + 36U);
    t11 = *((char **)t10);
    t12 = (t0 + 652U);
    t13 = *((char **)t12);
    xsi_vlog_generic_get_array_select_value(t5, 4, t4, t8, t11, 2, 1, t13, 4, 2);
    t12 = (t0 + 3132);
    t14 = (t12 + 32U);
    t15 = *((char **)t14);
    t16 = (t15 + 40U);
    t17 = *((char **)t16);
    t18 = (t17 + 4U);
    t19 = 15U;
    t20 = t19;
    t21 = (t5 + 4U);
    t22 = *((unsigned int *)t5);
    t19 = (t19 & t22);
    t23 = *((unsigned int *)t21);
    t20 = (t20 & t23);
    t24 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t24 & 4294967280U);
    t25 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t25 | t19);
    t26 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t26 & 4294967280U);
    t27 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t27 | t20);
    xsi_driver_vfirst_trans(t12, 0, 3);
    t28 = (t0 + 3036);
    *((int *)t28) = 1;

LAB1:    return;
}

static void A77_5(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 2704U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(77, ng0);
    t2 = (t0 + 3044);
    *((int *)t2) = 1;
    t3 = (t0 + 2732);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(78, ng0);

LAB5:    xsi_set_current_line(79, ng0);
    t4 = (t0 + 1180U);
    t5 = *((char **)t4);

LAB6:    t4 = ((char*)((ng1)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t4, 4);
    if (t6 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng3)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng5)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng7)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng13)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng2)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng4)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng6)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB21;

LAB22:    t2 = ((char*)((ng8)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB23;

LAB24:    t2 = ((char*)((ng14)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB25;

LAB26:    t2 = ((char*)((ng15)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB27;

LAB28:    t2 = ((char*)((ng16)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB29;

LAB30:    t2 = ((char*)((ng17)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB31;

LAB32:    t2 = ((char*)((ng18)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB33;

LAB34:    t2 = ((char*)((ng19)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB35;

LAB36:    t2 = ((char*)((ng12)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t6 == 1)
        goto LAB37;

LAB38:
LAB39:    goto LAB2;

LAB7:    xsi_set_current_line(80, ng0);
    t7 = ((char*)((ng12)));
    t8 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t8, t7, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB9:    xsi_set_current_line(81, ng0);
    t3 = ((char*)((ng1)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB11:    xsi_set_current_line(82, ng0);
    t3 = ((char*)((ng3)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB13:    xsi_set_current_line(83, ng0);
    t3 = ((char*)((ng5)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB15:    xsi_set_current_line(84, ng0);
    t3 = ((char*)((ng7)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB17:    xsi_set_current_line(85, ng0);
    t3 = ((char*)((ng13)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB19:    xsi_set_current_line(86, ng0);
    t3 = ((char*)((ng2)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB21:    xsi_set_current_line(87, ng0);
    t3 = ((char*)((ng4)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB23:    xsi_set_current_line(88, ng0);
    t3 = ((char*)((ng6)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB25:    xsi_set_current_line(89, ng0);
    t3 = ((char*)((ng8)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB27:    xsi_set_current_line(90, ng0);
    t3 = ((char*)((ng14)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB29:    xsi_set_current_line(91, ng0);
    t3 = ((char*)((ng15)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB31:    xsi_set_current_line(92, ng0);
    t3 = ((char*)((ng16)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB33:    xsi_set_current_line(93, ng0);
    t3 = ((char*)((ng17)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB35:    xsi_set_current_line(94, ng0);
    t3 = ((char*)((ng18)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

LAB37:    xsi_set_current_line(95, ng0);
    t3 = ((char*)((ng19)));
    t4 = (t0 + 1496);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 4, 0LL);
    goto LAB39;

}

static void C99_6(char *t0)
{
    char t4[8];
    char t12[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    char *t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    int t36;
    int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    char *t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    char *t59;

LAB0:    t1 = (t0 + 2832U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 828U);
    t3 = *((char **)t2);
    t2 = (t0 + 1180U);
    t5 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t4 + 4U);
    t6 = (t5 + 4U);
    t7 = *((unsigned int *)t6);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 15U);
    if (t11 != 0)
        goto LAB7;

LAB5:    if (*((unsigned int *)t6) == 0)
        goto LAB4;

LAB6:    *((unsigned int *)t4) = 1;
    *((unsigned int *)t2) = 1;

LAB7:    t13 = *((unsigned int *)t3);
    t14 = *((unsigned int *)t4);
    t15 = (t13 & t14);
    *((unsigned int *)t12) = t15;
    t16 = (t3 + 4U);
    t17 = (t4 + 4U);
    t18 = (t12 + 4U);
    t19 = *((unsigned int *)t16);
    t20 = *((unsigned int *)t17);
    t21 = (t19 | t20);
    *((unsigned int *)t18) = t21;
    t22 = *((unsigned int *)t18);
    t23 = (t22 != 0);
    if (t23 == 1)
        goto LAB8;

LAB9:
LAB10:    t44 = (t0 + 3168);
    t45 = (t44 + 32U);
    t46 = *((char **)t45);
    t47 = (t46 + 40U);
    t48 = *((char **)t47);
    t49 = (t48 + 4U);
    t50 = 1U;
    t51 = t50;
    t52 = (t12 + 4U);
    t53 = *((unsigned int *)t12);
    t50 = (t50 & t53);
    t54 = *((unsigned int *)t52);
    t51 = (t51 & t54);
    t55 = *((unsigned int *)t48);
    *((unsigned int *)t48) = (t55 & 4294967294U);
    t56 = *((unsigned int *)t48);
    *((unsigned int *)t48) = (t56 | t50);
    t57 = *((unsigned int *)t49);
    *((unsigned int *)t49) = (t57 & 4294967294U);
    t58 = *((unsigned int *)t49);
    *((unsigned int *)t49) = (t58 | t51);
    xsi_driver_vfirst_trans(t44, 0, 0);
    t59 = (t0 + 3052);
    *((int *)t59) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB8:    t24 = *((unsigned int *)t12);
    t25 = *((unsigned int *)t18);
    *((unsigned int *)t12) = (t24 | t25);
    t26 = (t3 + 4U);
    t27 = (t4 + 4U);
    t28 = *((unsigned int *)t3);
    t29 = (~(t28));
    t30 = *((unsigned int *)t26);
    t31 = (~(t30));
    t32 = *((unsigned int *)t4);
    t33 = (~(t32));
    t34 = *((unsigned int *)t27);
    t35 = (~(t34));
    t36 = (t29 & t31);
    t37 = (t33 & t35);
    t38 = (~(t36));
    t39 = (~(t37));
    t40 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t40 & t38);
    t41 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t41 & t39);
    t42 = *((unsigned int *)t12);
    *((unsigned int *)t12) = (t42 & t38);
    t43 = *((unsigned int *)t12);
    *((unsigned int *)t12) = (t43 & t39);
    goto LAB10;

}


extern void work_m_00000000000848908890_2688190043_init()
{
	static char *pe[] = {(void *)A53_0,(void *)C65_1,(void *)I67_2,(void *)A69_3,(void *)C75_4,(void *)A77_5,(void *)C99_6};
	xsi_register_didat("work_m_00000000000848908890_2688190043", "isim/_tmp/work/m_00000000000848908890_2688190043.didat");
	xsi_register_executes(pe);
}
