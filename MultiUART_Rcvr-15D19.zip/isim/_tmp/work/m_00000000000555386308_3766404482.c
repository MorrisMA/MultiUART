/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0xef153c89 */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/XProjects/ISE10.1i/MultiUART/GenPar.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {31U, 0U};
static unsigned int ng3[] = {1U, 0U};
static unsigned int ng4[] = {63U, 0U};
static unsigned int ng5[] = {2U, 0U};
static unsigned int ng6[] = {127U, 0U};
static unsigned int ng7[] = {3U, 0U};
static unsigned int ng8[] = {255U, 0U};



static void A45_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 1708U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(45, ng0);
    t2 = (t0 + 2272);
    *((int *)t2) = 1;
    t3 = (t0 + 1736);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(46, ng0);

LAB5:    xsi_set_current_line(47, ng0);
    t4 = (t0 + 652U);
    t5 = *((char **)t4);

LAB6:    t4 = ((char*)((ng1)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t4, 2);
    if (t6 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng3)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng5)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng7)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB13;

LAB14:
LAB15:    goto LAB2;

LAB7:    xsi_set_current_line(48, ng0);
    t7 = ((char*)((ng2)));
    t8 = (t0 + 1140);
    xsi_vlogvar_generic_wait_assign_value(t8, t7, 2, 0, 0, 8, 0LL);
    goto LAB15;

LAB9:    xsi_set_current_line(49, ng0);
    t3 = ((char*)((ng4)));
    t4 = (t0 + 1140);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 8, 0LL);
    goto LAB15;

LAB11:    xsi_set_current_line(50, ng0);
    t3 = ((char*)((ng6)));
    t4 = (t0 + 1140);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 8, 0LL);
    goto LAB15;

LAB13:    xsi_set_current_line(51, ng0);
    t3 = ((char*)((ng8)));
    t4 = (t0 + 1140);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 8, 0LL);
    goto LAB15;

}

static void C55_1(char *t0)
{
    char t3[8];
    char t8[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    int t31;
    int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    char *t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    unsigned int t52;
    unsigned int t53;
    char *t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;

LAB0:    t1 = (t0 + 1836U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 1140);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 740U);
    t7 = *((char **)t6);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t7);
    t11 = (t9 & t10);
    *((unsigned int *)t8) = t11;
    t6 = (t5 + 4U);
    t12 = (t7 + 4U);
    t13 = (t8 + 4U);
    t14 = *((unsigned int *)t6);
    t15 = *((unsigned int *)t12);
    t16 = (t14 | t15);
    *((unsigned int *)t13) = t16;
    t17 = *((unsigned int *)t13);
    t18 = (t17 != 0);
    if (t18 == 1)
        goto LAB4;

LAB5:
LAB6:    memset(t3, 0, 8);
    t39 = (t3 + 4U);
    t40 = (t8 + 4U);
    t41 = *((unsigned int *)t8);
    t42 = *((unsigned int *)t8);
    t42 = (t42 & 1);
    if (*((unsigned int *)t40) != 0)
        goto LAB7;

LAB8:    t43 = 1;

LAB10:    t44 = (t43 <= 7);
    if (t44 == 1)
        goto LAB11;

LAB12:    *((unsigned int *)t3) = t42;

LAB9:    t46 = (t0 + 2340);
    t47 = (t46 + 32U);
    t48 = *((char **)t47);
    t49 = (t48 + 40U);
    t50 = *((char **)t49);
    t51 = (t50 + 4U);
    t52 = 1U;
    t53 = t52;
    t54 = (t3 + 4U);
    t55 = *((unsigned int *)t3);
    t52 = (t52 & t55);
    t56 = *((unsigned int *)t54);
    t53 = (t53 & t56);
    t57 = *((unsigned int *)t50);
    *((unsigned int *)t50) = (t57 & 4294967294U);
    t58 = *((unsigned int *)t50);
    *((unsigned int *)t50) = (t58 | t52);
    t59 = *((unsigned int *)t51);
    *((unsigned int *)t51) = (t59 & 4294967294U);
    t60 = *((unsigned int *)t51);
    *((unsigned int *)t51) = (t60 | t53);
    xsi_driver_vfirst_trans(t46, 0, 0);
    t61 = (t0 + 2280);
    *((int *)t61) = 1;

LAB1:    return;
LAB4:    t19 = *((unsigned int *)t8);
    t20 = *((unsigned int *)t13);
    *((unsigned int *)t8) = (t19 | t20);
    t21 = (t5 + 4U);
    t22 = (t7 + 4U);
    t23 = *((unsigned int *)t5);
    t24 = (~(t23));
    t25 = *((unsigned int *)t21);
    t26 = (~(t25));
    t27 = *((unsigned int *)t7);
    t28 = (~(t27));
    t29 = *((unsigned int *)t22);
    t30 = (~(t29));
    t31 = (t24 & t26);
    t32 = (t28 & t30);
    t33 = (~(t31));
    t34 = (~(t32));
    t35 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t35 & t33);
    t36 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t36 & t34);
    t37 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t37 & t33);
    t38 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t38 & t34);
    goto LAB6;

LAB7:    *((unsigned int *)t3) = 1;
    *((unsigned int *)t39) = 1;
    goto LAB9;

LAB11:    t41 = (t41 >> 1);
    t45 = (t41 & 1);
    t42 = (t42 ^ t45);

LAB13:    t43 = (t43 + 1);
    goto LAB10;

}

static void A57_2(char *t0)
{
    char t7[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;

LAB0:    t1 = (t0 + 1964U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(57, ng0);
    t2 = (t0 + 2288);
    *((int *)t2) = 1;
    t3 = (t0 + 1992);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(58, ng0);

LAB5:    xsi_set_current_line(59, ng0);
    t4 = (t0 + 564U);
    t5 = *((char **)t4);

LAB6:    t4 = ((char*)((ng1)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t4, 2);
    if (t6 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng3)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng5)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng7)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB13;

LAB14:
LAB15:    goto LAB2;

LAB7:    xsi_set_current_line(60, ng0);
    t8 = (t0 + 916U);
    t9 = *((char **)t8);
    memset(t7, 0, 8);
    t8 = (t7 + 4U);
    t10 = (t9 + 4U);
    t11 = *((unsigned int *)t9);
    t12 = (~(t11));
    *((unsigned int *)t7) = t12;
    *((unsigned int *)t8) = 0;
    if (*((unsigned int *)t10) != 0)
        goto LAB17;

LAB16:    t17 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t17 & 1U);
    t18 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t18 & 1U);
    t19 = (t0 + 1232);
    xsi_vlogvar_generic_wait_assign_value(t19, t7, 2, 0, 0, 1, 0LL);
    goto LAB15;

LAB9:    xsi_set_current_line(61, ng0);
    t3 = (t0 + 916U);
    t4 = *((char **)t3);
    t3 = (t0 + 1232);
    xsi_vlogvar_generic_wait_assign_value(t3, t4, 2, 0, 0, 1, 0LL);
    goto LAB15;

LAB11:    xsi_set_current_line(62, ng0);
    t3 = ((char*)((ng3)));
    t4 = (t0 + 1232);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 1, 0LL);
    goto LAB15;

LAB13:    xsi_set_current_line(63, ng0);
    t3 = ((char*)((ng1)));
    t4 = (t0 + 1232);
    xsi_vlogvar_generic_wait_assign_value(t4, t3, 2, 0, 0, 1, 0LL);
    goto LAB15;

LAB17:    t13 = *((unsigned int *)t7);
    t14 = *((unsigned int *)t10);
    *((unsigned int *)t7) = (t13 | t14);
    t15 = *((unsigned int *)t8);
    t16 = *((unsigned int *)t10);
    *((unsigned int *)t8) = (t15 | t16);
    goto LAB16;

}

static void C67_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    char *t20;

LAB0:    t1 = (t0 + 2092U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 1232);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t0 + 2376);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    t10 = (t9 + 4U);
    t11 = 1U;
    t12 = t11;
    t13 = (t4 + 4U);
    t14 = *((unsigned int *)t4);
    t11 = (t11 & t14);
    t15 = *((unsigned int *)t13);
    t12 = (t12 & t15);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 & 4294967294U);
    t17 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t17 | t11);
    t18 = *((unsigned int *)t10);
    *((unsigned int *)t10) = (t18 & 4294967294U);
    t19 = *((unsigned int *)t10);
    *((unsigned int *)t10) = (t19 | t12);
    xsi_driver_vfirst_trans(t5, 0, 0);
    t20 = (t0 + 2296);
    *((int *)t20) = 1;

LAB1:    return;
}


extern void work_m_00000000000555386308_3766404482_init()
{
	static char *pe[] = {(void *)A45_0,(void *)C55_1,(void *)A57_2,(void *)C67_3};
	xsi_register_didat("work_m_00000000000555386308_3766404482", "isim/_tmp/work/m_00000000000555386308_3766404482.didat");
	xsi_register_executes(pe);
}
